In this distribution is included following files:

- SVJourn3 standart distribution;
- Additional files for the EPJC journal:

  svepjc3.clo        EPJC journal class option
  template-epjc.tex  EPJC template
  svjourn3-epjc.tex  EPJC sample (.tex}
  svjourn3-epjc.pdf  EPJC sample (.pdf)
