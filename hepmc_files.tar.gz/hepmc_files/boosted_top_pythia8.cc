//
// Read in process from file, record to hepmc output

#include "Pythia8/Pythia.h" // Include Pythia headers.
#include "Pythia8/Pythia8ToHepMC.h"
#include "HepMC/GenEvent.h"
#include "HepMC/IO_GenEvent.h" 
#include <sstream>

 using namespace Pythia8; // Let Pythia8:: be implicit.
 int main( int argc, char** argv ) { // Begin main program.
// // Set up generation.
// // Declare Pythia object

  if( argc != 4 ) {

	cout << "Input format: ./program input.file output.file random_seed" << endl;
	return 1;

  }

  const int myseed = atoi( argv[3] );

  stringstream ss;
  ss << "Random:seed = " << myseed;

  HepMC::Pythia8ToHepMC ToHepMC;

 Pythia pythia;
 pythia.readFile( argv[1] );
 pythia.readString( ss.str().c_str() );
 pythia.init();

 const int nEvent = pythia.mode("Main:numberOfEvents");

// // Generate event(s).

 HepMC::IO_GenEvent ascii_io( argv[2], std::ios::out);

  for( int iEvent = 0; iEvent < nEvent; iEvent++ ) {

	if( !pythia.next() ) {

		cout << "Error generating event: " << iEvent << endl;
		return 1;
		
	}

	HepMC::GenEvent* hepmcevt = new HepMC::GenEvent();
	ToHepMC.fill_next_event( pythia, hepmcevt );

	ascii_io << hepmcevt;
	delete hepmcevt;

  }

  pythia.statistics();
 // End main program with error-free return.
 return 0;
 }

